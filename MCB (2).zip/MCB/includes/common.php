<?php
$con = mysqli_connect("localhost", "root", "secret@9", "User")or die($mysqli_error($con));
?>
